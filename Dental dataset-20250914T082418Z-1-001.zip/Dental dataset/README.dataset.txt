# Tooth > 2025-01-25 1:22pm
https://universe.roboflow.com/akshay-wis4g/tooth-b278v

Provided by a Roboflow user
License: CC BY 4.0

